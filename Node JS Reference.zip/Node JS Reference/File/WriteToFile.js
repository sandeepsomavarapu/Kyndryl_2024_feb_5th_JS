var fs = require("fs");

console.log("Going to write the data  into existing file");

fs.writeFile('kyndryl.txt', 'nodejs(server side framework)', function(err) {
   if (err) {
      return console.error(err);
   }
   
   console.log("Data written successfully!");
   console.log("Let's read newly written data");

   fs.readFile('kyndryl.txt', function (err, data) {
      if (err) {
         return console.error(err);
      }
      console.log("Asynchronous read: " + data.toString());
   });
});